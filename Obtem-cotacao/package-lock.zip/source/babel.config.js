module.exports = {
    plugins: ['babel-plugin-rewire'],
  };